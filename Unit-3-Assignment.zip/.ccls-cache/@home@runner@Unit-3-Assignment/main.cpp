#include <iostream>
using namespace std;
/* Liz Bell 
COSC-1436-57002 
Repl.it
This program peforms the artimetic operations of addition, subtraction, multipication, division and modulus. The users will input numbers 1-4 and the program will output answers accorrdingly */



int main() 
{
  //INPUT: declaring  and initilize variables
  double number1, number2;
  int number3, number4;
 

  //ask user for input
  cout << "Please enter number 1: ";
  cin >> number1;
  cout << "\nPlease enter number 2: ";
  cin >> number2;
  cout << "\nPlease enter number 3 (integers only!): ";
  cin >> number3;
  cout << "\nPlease enter number 4(integers only!): ";
  cin >> number4;

  //PROCESS: perform artimetic operations
  double addition, subtraction, multiplication, division;
  int modulus;

  //OUTPUT
  
  //Addition
  addition = number1 + number2; //PROCESS
  cout << "\nAddiiton" << " (" << number1 << " + " << number2 << "): " << addition << endl; //Addition output

  //Subtraction
  subtraction = number1 - number2; //PROCESS
  cout << "\nSubtraction" << " (" << number1 << " - " << number2<< "): " << subtraction << endl;  //Subtraction output

  //Multiplication
  multiplication = number1 * number2; //PROCESS
  cout << "\nMultiplication" << " ("<< number1 << " * " << number2 << "): " << multiplication << endl; //Multiplication output

  //Division
  if (number2 == 0)//Check if input = 0, if so, display error message
  {
    cout << "\n Your number 2 input was 0, cannot divide by 0, try again" << endl;
  } 
  else //calculate and output division if input > 0
  { 
    division = number1 / number2; //PROCESS
    cout << "\nDivision" << " (" << number1 << " / " << number2 << "): " << division << endl;
  }
  
  //Modulus
  if (number4 == 0)//Check if input = 0, if so, display error message
  {
    cout << "\nNumber 4 input was 0, cannot divide by 0" << endl;
  }
  else //calculate and output modulus if input > 0
  {
    modulus = number3 % number4; //PROCESS
    cout << "\nModulus" << " (" << number3 << " % " << number4 << "): "<< modulus << endl;
  }
    
  return 0;
}